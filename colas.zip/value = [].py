import pygame
import random
import os

pygame.init()

# -----------------------------
# AJUSTES DE VOLUMEN (modifica aquí)
# -----------------------------
volumen_musica = 0.3
volumen_game_over = 0.3
volumen_escudo = 0.3
volumen_caja = 0.3
volumen_golpe_con_escudo = 0.3
volumen_golpe_sin_escudo = 0.3

# Música de fondo - LOOP INFINITO MEJORADO
pygame.mixer.music.load("musica_fondo.wav")
pygame.mixer.music.play(-1)  # -1 significa loop infinito
pygame.mixer.music.set_volume(volumen_musica)

# Sonidos
sonido_game_over = pygame.mixer.Sound("game_over.wav")
sonido_game_over.set_volume(volumen_game_over)

sonido_escudo = pygame.mixer.Sound("shield_on.wav")
sonido_escudo.set_volume(volumen_escudo)

# NUEVOS SONIDOS
sonido_caja = pygame.mixer.Sound("box_break.wav")
sonido_caja.set_volume(volumen_caja)

sonido_golpe_con_escudo = pygame.mixer.Sound("hit_shield.wav")
sonido_golpe_con_escudo.set_volume(volumen_golpe_con_escudo)

sonido_golpe_sin_escudo = pygame.mixer.Sound("hit.wav")
sonido_golpe_sin_escudo.set_volume(volumen_golpe_sin_escudo)

# -----------------------------
# RESOLUCIÓN DEL JUEGO
# -----------------------------
ANCHO = 1280
ALTO = 650
ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Vs. Seeker - Esquivar")

BLANCO = (255, 255, 255)

# Jugador
player_size = 110
player_vel = 11

# Enemigos
enemy_size = 150
enemy_vel_inicial = 12

clock = pygame.time.Clock()

# Fondo
background = pygame.image.load("background.png")
background = pygame.transform.scale(background, (ANCHO, ALTO))

bg_y1 = 0
bg_y2 = -ALTO
bg_speed = 15

# Explosiones
explosion_frames = [
    pygame.image.load("explosion_0.png"),
    pygame.image.load("explosion_1.png"),
    pygame.image.load("explosion_2.png"),
    pygame.image.load("explosion_3.png")
]
explosion_frames = [pygame.transform.scale(img, (player_size, player_size)) for img in explosion_frames]

# ============================================================
# Cargar sprites del jugador (3 frames)
# ============================================================
def cargar_sprites(prefix):
    frames = []
    for i in range(3):
        filepath = f"{prefix}_{i}.png"
        if os.path.exists(filepath):
            img = pygame.image.load(filepath)
        else:
            img = pygame.image.load(f"{prefix}_0.png")
        img = pygame.transform.scale(img, (player_size, player_size))
        frames.append(img)
    return frames

idle_left  = cargar_sprites("idle_left")
idle_right = cargar_sprites("idle_right")
walk_left  = cargar_sprites("walk_left")
walk_right = cargar_sprites("walk_right")

# ============================================================
# Cargar sprites del enemigo (12 frames)
# ============================================================
def cargar_sprites_enemigo(prefix):
    frames = []
    for i in range(12):
        filename = f"{prefix}_{i}.png"
        if os.path.exists(filename):
            img = pygame.image.load(filename)
        else:
            img = pygame.image.load(f"{prefix}_0.png")
        img = pygame.transform.scale(img, (enemy_size, enemy_size))
        frames.append(img)
    return frames

enemy_move_frames = cargar_sprites_enemigo("enemy_move")

# ============================================================
# Cargar sprites del ESCUDO (8 frames)
# ============================================================
def cargar_sprites_escudo(prefix):
    frames = []
    for i in range(8):
        filename = f"{prefix}_{i}.png"
        img = pygame.image.load(filename)
        img = pygame.transform.scale(img, (player_size + 40, player_size + 40))
        frames.append(img)
    return frames

shield_frames = cargar_sprites_escudo("shield")

# ============================================================
# Cargar sprites de CAJA POWER-UP (3 frames)
# ============================================================
powerup_box_frames = []
for i in range(3):
    img = pygame.image.load(f"box_{i}.png")
    img = pygame.transform.scale(img, (80, 80))
    powerup_box_frames.append(img)

# ============================================================
# Colisión
# ============================================================
def colision(px, py, ex, ey, size=enemy_size):
    return (
        px < ex + size and
        px + player_size > ex and
        py < ey + size and
        py + player_size > ey
    )

# ============================================================
# Texto
# ============================================================
def dibujar_texto(superficie, texto, tamaño, x, y, color=(255,255,255)):
    fuente = pygame.font.SysFont(None, tamaño)
    render = fuente.render(texto, True, color)
    superficie.blit(render, (x, y))

# ============================================================
# Animación explosión
# ============================================================
def animacion_explosion(x, y, fondo_img, fondo_y1, fondo_y2):
    for frame in explosion_frames:
        ventana.blit(fondo_img, (0, fondo_y1))
        ventana.blit(fondo_img, (0, fondo_y2))
        ventana.blit(frame, (x, y))
        pygame.display.update()
        pygame.time.delay(120)

# ============================================================
# Game Over
# ============================================================
def mostrar_game_over():
    boton_rect = pygame.Rect(ANCHO//2 - 150, ALTO//2 + 50, 300, 70)

    while True:
        ventana.fill((0, 0, 0))
        dibujar_texto(ventana, "GAME OVER", 100, ANCHO//2 - 220, ALTO//2 - 150, (255, 0, 0))

        pygame.draw.rect(ventana, (0,150,255), boton_rect)
        dibujar_texto(ventana, "REINICIAR", 50, ANCHO//2 - 110, ALTO//2 + 70)

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                exit()

            if e.type == pygame.MOUSEBUTTONDOWN and boton_rect.collidepoint(e.pos):
                pygame.mixer.music.load("musica_fondo.wav")
                pygame.mixer.music.play(-1)
                pygame.mixer.music.set_volume(volumen_musica)

                sonido_game_over.set_volume(volumen_game_over)
                sonido_escudo.set_volume(volumen_escudo)
                sonido_caja.set_volume(volumen_caja)
                sonido_golpe_con_escudo.set_volume(volumen_golpe_con_escudo)
                sonido_golpe_sin_escudo.set_volume(volumen_golpe_sin_escudo)
                return

        pygame.display.update()

# ============================================================
# Crear enemigo con velocidad independiente y límites diferentes
# ============================================================
def crear_enemigo(enemigos_existentes=[]):
    # Diferentes tipos de enemigos con límites de velocidad distintos
    enemy_type = random.choice(["rapido", "normal", "lento", "variable"])
    
    if enemy_type == "rapido":
        vel_inicial = random.randint(16, 20)
        vel_maxima = 32
        incremento = 0.8
    elif enemy_type == "normal":
        vel_inicial = random.randint(12, 16)
        vel_maxima = 28
        incremento = 0.6
    elif enemy_type == "lento":
        vel_inicial = random.randint(8, 12)
        vel_maxima = 24
        incremento = 0.5
    else:  # variable
        vel_inicial = random.randint(10, 18)
        vel_maxima = 30
        incremento = 0.7
    
    # Encontrar una posición x que esté separada de otros enemigos
    intentos = 0
    while intentos < 50:  # Límite de intentos para evitar bucle infinito
        x = random.randint(0, ANCHO - enemy_size)
        
        # Verificar separación con otros enemigos
        posicion_valida = True
        for enemigo in enemigos_existentes:
            if abs(x - enemigo["x"]) < 135:  # Separación mínima de 135 píxeles
                posicion_valida = False
                break
        
        if posicion_valida:
            break
            
        intentos += 1
        # Si no encontramos posición después de muchos intentos, usar cualquier posición
        if intentos >= 50:
            x = random.randint(0, ANCHO - enemy_size)
            break
    
    return {
        "x": x,
        "y": -enemy_size,
        "vel": vel_inicial,
        "vel_maxima": vel_maxima,
        "incremento": incremento,
        "tipo": enemy_type,
        "frame": 0
    }

# ============================================================
# FUNCIÓN PRINCIPAL DE JUEGO
# ============================================================
def jugar():
    global bg_y1, bg_y2

    bg_y1 = 0
    bg_y2 = -ALTO
    score = 0

    player_x = ANCHO // 2
    player_y = ALTO - player_size - 10

    enemigos = []
    max_enemigos = 4  # Máximo de 4 enemigos

    # Comenzar con UN SOLO enemigo
    primer = crear_enemigo(enemigos)
    primer["y"] = 0
    enemigos.append(primer)

    frame_index = 0
    frame_delay = 7
    frame_timer = 0

    enemy_frame_speed = 0.8

    shield_active = True
    sonido_escudo.play()
    shield_start = pygame.time.get_ticks()
    shield_duration = 8000  # Reducido para mayor dificultad
    shield_frame_index = 0
    shield_frame_speed = 0.35

    # NUEVAS VARIABLES PARA INVULNERABILIDAD
    invulnerable = False
    invulnerable_start = 0
    invulnerable_duration = 3000  # 3 segundos
    blink_timer = 0
    blink_interval = 100  # milisegundos entre parpadeos
    player_visible = True

    powerup_box_active = False
    powerup_box_x = 0
    powerup_box_y = -100
    powerup_frame_index = 0
    powerup_frame_speed = 0.5

    last_spawn_level = 0
    enemies_spawned = 1  # Ya empezamos con 1 enemigo

    direction = "right"
    moving = False
    fondo_activo = True
    
    # VARIABLES PARA PAUSA
    paused = False
    pause_time_accumulated = 0  # Tiempo acumulado en pausa para ajustar los timers
    last_pause_time = 0

    while True:
        pygame.time.delay(10)

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_SPACE:
                    paused = not paused
                    if paused:
                        # Entrando en pausa - guardar el tiempo actual
                        last_pause_time = pygame.time.get_ticks()
                        pygame.mixer.music.pause()
                        # Pausar todos los sonidos (no hay función directa, pero podemos bajar volumen a 0)
                        # En su lugar, no reproduciremos sonidos nuevos durante pausa
                    else:
                        # Saliendo de pausa - calcular tiempo acumulado
                        pause_time_accumulated += pygame.time.get_ticks() - last_pause_time
                        pygame.mixer.music.unpause()

        if paused:
            # Mostrar pantalla de pausa
            ventana.blit(background, (0, bg_y1))
            ventana.blit(background, (0, bg_y2))
            
            # Dibujar todos los elementos en su posición actual
            # ANIMACIÓN JUGADOR (congelada)
            sprite = walk_left[frame_index] if moving and direction == "left" else \
                     walk_right[frame_index] if moving else \
                     idle_left[frame_index] if direction == "left" else \
                     idle_right[frame_index]

            # Dibujar jugador solo si es visible (no durante los parpadeos de invulnerabilidad)
            if not invulnerable or player_visible:
                ventana.blit(sprite, (player_x, player_y))

            # ANIMACIÓN ENEMIGOS (congelada)
            for enemigo in enemigos:
                ventana.blit(enemy_move_frames[int(enemigo["frame"])], (enemigo["x"], enemigo["y"]))

            # ANIMACIÓN ESCUDO (congelada)
            if shield_active:
                shield_img = shield_frames[int(shield_frame_index)]
                shield_rect = shield_img.get_rect(center=(player_x + player_size//2, player_y + player_size//2))
                ventana.blit(shield_img, shield_rect)

            # CAJA POWER-UP (congelada)
            if powerup_box_active:
                ventana.blit(powerup_box_frames[int(powerup_frame_index)], (powerup_box_x, powerup_box_y))

            # Texto de pausa
            dibujar_texto(ventana, "PAUSA", 100, ANCHO//2 - 120, ALTO//2 - 50, (255, 255, 0))
            dibujar_texto(ventana, "Presiona ESPACIO para continuar", 40, ANCHO//2 - 220, ALTO//2 + 50)
            dibujar_texto(ventana, f"Puntos: {score}", 40, 20, 20)

            pygame.display.update()
            clock.tick(60)
            continue  # Saltar el resto del bucle mientras está en pausa

        # Si no está en pausa, continuar con el juego normal
        if fondo_activo:
            bg_y1 += bg_speed
            bg_y2 += bg_speed
            if bg_y1 >= ALTO:
                bg_y1 = bg_y2 - ALTO
            if bg_y2 >= ALTO:
                bg_y2 = bg_y1 - ALTO

        ventana.blit(background, (0, bg_y1))
        ventana.blit(background, (0, bg_y2))

        teclas = pygame.key.get_pressed()
        moving = False

        if teclas[pygame.K_LEFT] and player_x > 0:
            player_x -= player_vel
            direction = "left"
            moving = True

        if teclas[pygame.K_RIGHT] and player_x < ANCHO - player_size:
            player_x += player_vel
            direction = "right"
            moving = True

        # -------------------------
        # MOVIMIENTO ENEMIGOS
        # -------------------------
        for enemigo in enemigos:
            enemigo["y"] += enemigo["vel"]

            if enemigo["y"] > ALTO:
                score += 1
                enemigo["y"] = -enemy_size
                
                # Encontrar una nueva posición x que esté separada de otros enemigos
                intentos = 0
                while intentos < 50:
                    nueva_x = random.randint(0, ANCHO - enemy_size)
                    
                    # Verificar separación con otros enemigos
                    posicion_valida = True
                    for otro_enemigo in enemigos:
                        if otro_enemigo != enemigo and abs(nueva_x - otro_enemigo["x"]) < 135:
                            posicion_valida = False
                            break
                    
                    if posicion_valida:
                        enemigo["x"] = nueva_x
                        break
                        
                    intentos += 1
                    # Si no encontramos posición después de muchos intentos, usar cualquier posición
                    if intentos >= 50:
                        enemigo["x"] = random.randint(0, ANCHO - enemy_size)
                        break

                # Incrementar velocidad según el tipo de enemigo
                enemigo["vel"] += enemigo["incremento"]
                if enemigo["vel"] > enemigo["vel_maxima"]:
                    enemigo["vel"] = enemigo["vel_maxima"]

                # Power-ups balanceados - aparecen con más frecuencia para compensar la dificultad
                if not powerup_box_active and random.randint(1, 4) == 1:  # 1/4 de probabilidad
                    powerup_box_active = True
                    powerup_box_x = random.randint(0, ANCHO - 80)
                    powerup_box_y = -80

        # NUEVOS ENEMIGOS CADA 50 PUNTOS
        if score >= 50 and enemies_spawned < max_enemigos:
            # Verificar si hemos alcanzado un múltiplo de 50 puntos
            current_enemy_level = score // 50
            if current_enemy_level > last_spawn_level:
                nuevo_enemigo = crear_enemigo(enemigos)
                # Posicionar el nuevo enemigo arriba de la pantalla
                nuevo_enemigo["y"] = -enemy_size
                enemigos.append(nuevo_enemigo)
                enemies_spawned += 1
                last_spawn_level = current_enemy_level

        # -------------------------
        # CAJA POWER-UP
        # -------------------------
        if powerup_box_active:
            powerup_box_y += 9  # Velocidad aumentada para mayor desafío

            powerup_frame_index += powerup_frame_speed
            if powerup_frame_index >= len(powerup_box_frames):
                powerup_frame_index = 0

            ventana.blit(powerup_box_frames[int(powerup_frame_index)], (powerup_box_x, powerup_box_y))

            if colision(player_x, player_y, powerup_box_x, powerup_box_y, 80):

                # SONIDO NUEVO → ROMPER CAJA
                sonido_caja.play()

                shield_active = True
                sonido_escudo.play()
                # Ajustar el tiempo del escudo considerando el tiempo en pausa
                shield_start = pygame.time.get_ticks() - pause_time_accumulated
                powerup_box_active = False

            if powerup_box_y > ALTO:
                powerup_box_active = False

        # -------------------------
        # COLISIONES CON ENEMIGOS
        # -------------------------
        for enemigo in enemigos:
            if colision(player_x, player_y, enemigo["x"], enemigo["y"]):

                # Si el jugador es invulnerable, ignorar la colisión
                if invulnerable:
                    continue

                if shield_active:

                    # SONIDO NUEVO → GOLPE CON ESCUDO
                    sonido_golpe_con_escudo.play()

                    # Activar efecto de invulnerabilidad
                    invulnerable = True
                    # Ajustar el tiempo de invulnerabilidad considerando el tiempo en pausa
                    invulnerable_start = pygame.time.get_ticks() - pause_time_accumulated
                    shield_active = False
                    enemigo["y"] = -enemy_size
                    continue

                # SIN ESCUDO → MUERTE
                fondo_activo = False
                fondo_final_y1 = bg_y1
                fondo_final_y2 = bg_y2

                # SONIDO NUEVO → GOLPE FINAL
                sonido_golpe_sin_escudo.play()

                pygame.mixer.music.fadeout(800)
                animacion_explosion(player_x, player_y, background, fondo_final_y1, fondo_final_y2)

                sonido_game_over.play()
                pygame.time.delay(900)
                mostrar_game_over()
                return

        # -------------------------
        # CONTROL DE INVULNERABILIDAD Y PARPADEO
        # -------------------------
        if invulnerable:
            current_time = pygame.time.get_ticks() - pause_time_accumulated
            
            # Verificar si ha pasado el tiempo de invulnerabilidad
            if current_time - invulnerable_start > invulnerable_duration:
                invulnerable = False
                player_visible = True
            else:
                # Efecto de parpadeo - cambiar visibilidad cada blink_interval
                if current_time - blink_timer > blink_interval:
                    blink_timer = current_time
                    player_visible = not player_visible

        # ANIMACIÓN JUGADOR
        frame_timer += 1
        if frame_timer >= frame_delay:
            frame_timer = 0
            frame_index = (frame_index + 1) % 3

        sprite = walk_left[frame_index] if moving and direction == "left" else \
                 walk_right[frame_index] if moving else \
                 idle_left[frame_index] if direction == "left" else \
                 idle_right[frame_index]

        # Dibujar jugador solo si es visible (no durante los parpadeos de invulnerabilidad)
        if not invulnerable or player_visible:
            ventana.blit(sprite, (player_x, player_y))

        # ANIMACIÓN ENEMIGOS
        for enemigo in enemigos:
            enemigo["frame"] += enemy_frame_speed
            if enemigo["frame"] >= len(enemy_move_frames):
                enemigo["frame"] = 0
            ventana.blit(enemy_move_frames[int(enemigo["frame"])], (enemigo["x"], enemigo["y"]))

        # ANIMACIÓN ESCUDO
        # Ajustar el tiempo del escudo considerando el tiempo en pausa
        tiempo_escudo = (pygame.time.get_ticks() - pause_time_accumulated) - shield_start
        if tiempo_escudo > shield_duration:
            shield_active = False

        if shield_active:
            shield_frame_index += shield_frame_speed
            if shield_frame_index >= len(shield_frames):
                shield_frame_index = 0
            shield_img = shield_frames[int(shield_frame_index)]
            shield_rect = shield_img.get_rect(center=(player_x + player_size//2, player_y + player_size//2))
            ventana.blit(shield_img, shield_rect)

        # Mostrar también la cantidad de enemigos actual
        dibujar_texto(ventana, f"Puntos: {score}", 40, 20, 20)
        dibujar_texto(ventana, f"Enemigos: {len(enemigos)}/{max_enemigos}", 40, 20, 70)

        pygame.display.update()
        clock.tick(60)

# LOOP PRINCIPAL
while True:
    jugar()

pygame.quit()